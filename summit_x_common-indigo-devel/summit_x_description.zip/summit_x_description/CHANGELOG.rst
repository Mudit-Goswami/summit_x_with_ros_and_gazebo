^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package summit_x_description
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.4 (2016-08-24)
------------------
* Fixed hardware interface
* Contributors: Jorge Arino

0.0.3 (2016-08-19)
------------------
* Minor change
* Added installation lines to CMakeLists.txt in summit_x_description
* Contributors: Jose Rapado

0.0.2 (2016-07-18)
------------------

0.0.1 (2016-07-08)
------------------
* Changed package.xml files
* summit_x_description: added correct position for the asus xtion camera
* summit_x_common: fixed link to robotnik_sensors
* summit_x_description: creating package. Migrating urdf descriptions to indigo
* Contributors: Jorge Arino, carlos3dx
